**To delete a pipeline**

This example deletes a pipeline named MySecondPipeline from AWS CodePipeline. Use the list-pipelines command to view a list of pipelines associated with your AWS account.

Command::

  aws codepipeline delete-pipeline --name MySecondPipeline


Output::

  None.